# VELYORA Android — première version native

Projet Android Studio prêt à ouvrir et compiler.
Fonctions : accueil, marketplace, vente, portefeuille, retrait démo, parrainage, assistant IA démo et profil.
Le logo VELYORA fourni est inclus.

Cette version ne réalise volontairement aucun paiement réel. Une version de production nécessite backend sécurisé, base de données, authentification réelle, intégration officielle du prestataire de paiement, journalisation, contrôles anti-fraude et conformité.
