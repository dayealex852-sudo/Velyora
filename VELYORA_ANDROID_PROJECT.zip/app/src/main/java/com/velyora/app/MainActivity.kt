package com.velyora.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var balance = 0L
    private val products = mutableListOf<String>()
    private val blue = Color.rgb(23,103,201)
    private val ink = Color.rgb(16,35,63)
    private val bg = Color.rgb(245,248,252)

    private fun money(n: Long) = NumberFormat.getNumberInstance(Locale.FRANCE).format(n) + " F CFA"
    private fun txt(s:String, size:Float=16f, bold:Boolean=false) = TextView(this).apply {
        text=s; textSize=size; setTextColor(ink); setPadding(12,8,12,8)
        if(bold) typeface=Typeface.DEFAULT_BOLD
    }
    private fun field(h:String)=EditText(this).apply{hint=h;setPadding(14,10,14,10)}
    private fun button(s:String, f:()->Unit)=Button(this).apply{ text=s; setTextColor(Color.WHITE); setBackgroundColor(blue); setOnClickListener{f()} }

    override fun onCreate(b:Bundle?){super.onCreate(b);auth()}

    private fun auth(){
        val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(24,30,24,30);setBackgroundColor(bg)}
        val logo=ImageView(this)
        assets.open("velyora-logo.jpg").use{logo.setImageBitmap(android.graphics.BitmapFactory.decodeStream(it))}
        c.addView(logo,LinearLayout.LayoutParams(-1,120))
        c.addView(txt("Bienvenue sur VELYORA",23f,true))
        c.addView(txt("Achetez, vendez et développez votre activité.",14f))
        c.addView(field("Nom complet")); c.addView(field("Numéro de téléphone"))
        c.addView(button("Créer mon compte"){home(makeFrame())})
        c.addView(txt("Version de démonstration : aucun paiement réel.",12f))
        setContentView(c)
    }

    private fun makeFrame():LinearLayout{
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg)}
        val scroll=ScrollView(this)
        val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,16,16,90)}
        scroll.addView(c);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply{gravity=Gravity.CENTER;setBackgroundColor(Color.WHITE)}
        listOf("⌂\nAccueil","🛍\nMarché","＋\nVendre","💰\nPortefeuille","◯\nProfil").forEachIndexed{i,s->
            nav.addView(Button(this).apply{text=s;setTextColor(blue);setOnClickListener{
                when(i){0->home(c);1->market(c);2->sell(c);3->wallet(c);4->profile(c)}
            }},LinearLayout.LayoutParams(0,70,1f))
        }
        root.addView(nav);setContentView(root);return c
    }
    private fun clear(c:LinearLayout,t:String){c.removeAllViews();c.addView(txt(t,24f,true))}
    private fun home(c:LinearLayout){clear(c,"Bonjour 👋");c.addView(txt("Solde disponible\n${money(balance)}",26f,true))
        c.addView(txt("Ventes : 0 F CFA\nCommandes : 0\nProduits : ${products.size}",15f))
        c.addView(txt("Actions rapides",19f,true))
        c.addView(button("🛍 Acheter"){market(c)});c.addView(button("🏪 Vendre"){sell(c)})
        c.addView(button("💰 Portefeuille"){wallet(c)});c.addView(button("🤝 Parrainage"){ref(c)})
        c.addView(button("🤖 Assistant IA"){ai(c)})
    }
    private fun market(c:LinearLayout){clear(c,"Marketplace");c.addView(field("🔍 Rechercher…"))
        listOf("Chaussures tendance — 10 000 F CFA","Accessoires téléphone — 5 000 F CFA","Sac moderne — 12 500 F CFA").forEach{
            c.addView(txt("🛍 $it",16f));c.addView(button("Acheter"){Toast.makeText(this,"Commande de démonstration créée.",Toast.LENGTH_SHORT).show()})
        }
        products.forEach{c.addView(txt("📦 $it",16f))}
    }
    private fun sell(c:LinearLayout){clear(c,"Ma boutique");val n=field("Nom du produit");val p=field("Prix en F CFA");val q=field("Quantité")
        c.addView(n);c.addView(p);c.addView(q);c.addView(button("Publier le produit"){if(n.text.isNotBlank()){products.add("${n.text} — ${p.text} F CFA");Toast.makeText(this,"Produit publié.",Toast.LENGTH_SHORT).show();market(c)}})
    }
    private fun wallet(c:LinearLayout){clear(c,"Portefeuille");c.addView(txt("Solde disponible\n${money(balance)}",26f,true));c.addView(button("Demander un retrait"){withdraw(c)});c.addView(txt("Historique\nAucune transaction.",15f))}
    private fun withdraw(c:LinearLayout){clear(c,"Demande de retrait");c.addView(txt("Solde : ${money(balance)}"));val a=field("Montant en F CFA");c.addView(a)
        c.addView(button("Confirmer"){val n=a.text.toString().toLongOrNull()?:0;if(n>0&&n<=balance){balance-=n;Toast.makeText(this,"Demande enregistrée en mode démo.",Toast.LENGTH_SHORT).show();wallet(c)}else Toast.makeText(this,"Montant invalide ou solde insuffisant.",Toast.LENGTH_SHORT).show()})
    }
    private fun ref(c:LinearLayout){clear(c,"Parrainage");c.addView(txt("Récompenses liées à l'activité commerciale réelle.\nCode : VELYORA-DEMO",16f))}
    private fun ai(c:LinearLayout){clear(c,"Assistant IA 🤖");c.addView(txt("Je peux expliquer les fonctions de VELYORA.",16f));c.addView(button("Comment vendre ?"){Toast.makeText(this,"Ouvrez Vendre puis ajoutez un produit.",Toast.LENGTH_SHORT).show()});c.addView(button("Comment retirer ?"){Toast.makeText(this,"Portefeuille → Demander un retrait.",Toast.LENGTH_SHORT).show()})}
    private fun profile(c:LinearLayout){clear(c,"Profil");c.addView(field("Nom complet"));c.addView(field("Téléphone"));c.addView(field("E-mail"));c.addView(button("Enregistrer"){Toast.makeText(this,"Profil enregistré.",Toast.LENGTH_SHORT).show()});c.addView(txt("Les vrais comptes et paiements seront connectés dans la version en ligne.",13f))}
}